<?php

namespace Pterodactyl\Events;

abstract class Event
{
}
