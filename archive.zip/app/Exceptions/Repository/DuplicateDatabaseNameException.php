<?php

namespace Pterodactyl\Exceptions\Repository;

use Pterodactyl\Exceptions\DisplayException;

class DuplicateDatabaseNameException extends DisplayException
{
}
